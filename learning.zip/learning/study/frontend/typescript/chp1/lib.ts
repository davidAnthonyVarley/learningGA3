console.log("");
console.log("*********");

interface isSized {
    length: number
}

interface BoxInterface {
    dosomething(): void;
}

abstract class TheoereticalDataBox<Type extends isSized> {

    abstract data: Type;
    abstract print(data: Type): void;

    abstract donon(): void;


}

export type someType = string | number;

class ActualDataBox<Type extends isSized> extends TheoereticalDataBox<Type> implements BoxInterface {

    data: Type;

    constructor(data: Type) {
        super();
        this.data = data;
    }

    print(data: Type) {
        console.log(data.length);
    }

    donon() { }
    dosomething(): void { }
}












console.log("*********");
console.log("");