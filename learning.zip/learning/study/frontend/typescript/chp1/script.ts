import { someType } from "./lib";

console.log("");
console.log("*********");

let p2: someType = 'john'

interface User {
    name: string,
    age?: number,
    email: string
}

type UserOptional = Partial<User>;

let uo1: UserOptional = { name: 'joey' };


console.log(p2);
console.log("*********");
console.log("");