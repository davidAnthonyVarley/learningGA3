import { useEffect, useContext, useState, createContext } from "react";

export const BooksContext = createContext();

export const BooksProvider =  ({children}) => {

    const [books, setBooks] = useState([]);

    useEffect( () => {
        fetch("books.json")
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json(); // Correct: Return the Promise from response.json()
      })
      .then(json => {
        setBooks(json);
      })
      .catch(err => {
        console.error("Error fetching or parsing books:", err);
      });

    }, []);

    return (

        <BooksContext.Provider value={books}>{children}</BooksContext.Provider>

    );

};

