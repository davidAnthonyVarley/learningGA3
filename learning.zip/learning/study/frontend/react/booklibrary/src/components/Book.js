import React from "react";
import '../App.css';

export default function Book({bookData}) {

    return (
        <div>
            <h4>here is a book</h4>
            <div>{bookData.title}</div>
        </div>
    );
    
}