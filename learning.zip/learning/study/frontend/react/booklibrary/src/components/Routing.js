import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import React  from "react";
import BookList from "./BookList";

export default function Routing() {

    return (
        
        <Router>
            <Routes>
                {/* <Route path="/books/:id">
                </Route> */}
                <Route path="/" element={<BookList></BookList>}></Route>
            </Routes>
        </Router>

    );

}