import React from "react";
import '../styles.css';
import { useState } from "react";

export default function Footer(content) {


    const year = new Date().getFullYear();

    return(

        <div className="footer">
            <p className="footer-text">This page was made in {year}</p>
        </div>

    );
}

