import React from "react";
import "../styles.css";
import MoviesGrid from "./MoviesGrid";

export default function WatchList() {
  return (
    <div>
      <h1 className="title">WatchList</h1>
      <MoviesGrid></MoviesGrid>
    </div>
  );
}
