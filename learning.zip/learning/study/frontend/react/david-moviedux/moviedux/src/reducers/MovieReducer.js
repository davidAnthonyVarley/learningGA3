export default function ticketReducer(state, action) {
  switch (action.type) {
    case MODIFY_MOVIE_NAME:

    default:
      return state;
  }
}
