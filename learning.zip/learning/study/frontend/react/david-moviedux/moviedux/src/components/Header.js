import React from "react";
import '../styles.css';

export default function Header() {

    return (
        <div className='header'>

            <img className="logo" src='logo.png' alt='moviedux logo'/>
            <h2 className="app-subtitle">its time for some popcorn</h2>

        </div>
    );
    
}